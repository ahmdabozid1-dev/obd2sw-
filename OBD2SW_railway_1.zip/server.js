const express = require('express');
const { Pool }  = require('pg');
const http      = require('http');
const path      = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── PostgreSQL (Railway provides DATABASE_URL automatically) ──────────────────
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

async function initDB() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS store (
      id    TEXT PRIMARY KEY,
      value JSONB NOT NULL
    )
  `);
  console.log('✅ Database ready');
}

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── GET /db — load the panel database ────────────────────────────────────────
app.get('/db', async (req, res) => {
  try {
    const r = await pool.query("SELECT value FROM store WHERE id='main'");
    if (!r.rows.length) return res.status(404).json({ error: 'empty' });
    res.json(r.rows[0].value);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── POST /db — save the panel database ───────────────────────────────────────
app.post('/db', async (req, res) => {
  try {
    await pool.query(`
      INSERT INTO store (id, value) VALUES ('main', $1)
      ON CONFLICT (id) DO UPDATE SET value = EXCLUDED.value
    `, [req.body]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── Proxy OBD2 API calls to 72.60.69.185 ─────────────────────────────────────
function proxyAPI(req, res) {
  const opts = {
    hostname: '72.60.69.185',
    port: 80,
    path: req.url,
    method: 'GET',
    headers: { 'User-Agent': 'OBD2SW/1.0' }
  };
  const proxy = http.request(opts, apiRes => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.writeHead(apiRes.statusCode, {
      'Content-Type': apiRes.headers['content-type'] || 'text/plain'
    });
    apiRes.pipe(res);
  });
  proxy.on('error', () => res.status(502).send('API unreachable'));
  proxy.end();
}

app.get('/apiuseradd/*', proxyAPI);
app.get('/apideluser/*', proxyAPI);
app.get('/apilogs/*',    proxyAPI);
app.get('/showallapi/*', proxyAPI);

// ── Start ─────────────────────────────────────────────────────────────────────
initDB()
  .then(() => app.listen(PORT, () => console.log(`🚀 OBD2SW on port ${PORT}`)))
  .catch(err => { console.error('DB error:', err); process.exit(1); });
